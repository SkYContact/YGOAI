gen181 WindBot 形态独立包
========================
两种用法（都在本目录运行）:
  1) 双击 WbGen181.exe —— 图形界面（推荐）
     服务器/端口/密码默认=本机 ai_duel --server 的回环 127.0.0.1:7911 / 密码 s
     卡组、模型下拉框自动扫描本目录与 Decks/，名字默认 gen181
  2) 命令行: WbRelay.exe -h <服务器IP> -p <端口> -w <房间密码> -n <名字> [-d 卡组.ydk] [-m model.onnx]

内容:
  WbRelay.exe        C# 壳（持 TCP 连接，与 WindBot 同款 CLI 风格）
  ai_duel.exe        C++ 决策核（--client stdio 模式；日志走 stderr）
  model.onnx(+.tab)  gen181 冠军策略（wbfield 岛，多卡组策略）
  AI_ChaosRitual.ydk 默认卡组（另备 Elfnote/Swordsoul/Labrynth 亦在策略内）

注意:
  - 决策核以本目录为工作目录（找 cards.cdb/script）；回放落 ./client_replay/
  - WB_TRACE=1 时壳侧落 ctos_trace.bin 调试帧流
  - 挂机保护/RETRY 排除重选/洪水熔断等护栏全部继承自 --client 实战代码

注: 本包为纯客户端(bot)角色，不含 script/ 目录（卡效果 lua 由服务器侧执行）；
    若想用本包内的 ai_duel.exe 另开本地服务器(--server)，需自行补 script/ 目录。
卡库 cards.cdb 不随包分发：首次启动 GUI 自动从 moecube 官方 CDN 下载
（https://cdn02.moecube.com:444/ygopro-database/zh-CN/cards.cdb），
界面上的「更新卡库」按钮随时可刷新到最新版。
